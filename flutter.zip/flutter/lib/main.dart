import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() {
  runApp(RobotArmApp());
}

class RobotArmApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Robot Arm Control',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: RobotArmHomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class RobotArmHomePage extends StatefulWidget {
  @override
  _RobotArmHomePageState createState() => _RobotArmHomePageState();
}

class _RobotArmHomePageState extends State<RobotArmHomePage> {
  String serverIp = "192.168.1.117";
  List<double> motors = [90, 90, 90, 90];
  List poses = [];
  String _runPoseStatus = "";

  @override
  void initState() {
    super.initState();
    fetchPoses();
  }

  String _ip() => serverIp.trim();

  void fetchPoses() async {
    try {
      final url = Uri.parse("http://${_ip()}/robot_arm_panel/get_poses.php");
      final response = await http.get(url);
      print("fetchPoses response: ${response.statusCode} ${response.body}");
      if (response.statusCode == 200) {
        setState(() {
          poses = json.decode(response.body);
        });
      }
    } catch (e) {
      print("fetchPoses error: $e");
    }
  }

  void savePose() async {
    try {
      final url = Uri.parse("http://${_ip()}/robot_arm_panel/save_pose.php");
      final response = await http.post(url, body: {
        "motor1": motors[0].toInt().toString(),
        "motor2": motors[1].toInt().toString(),
        "motor3": motors[2].toInt().toString(),
        "motor4": motors[3].toInt().toString(),
      });
      print("savePose response: ${response.statusCode} ${response.body}");
      fetchPoses();
    } catch (e) {
      print("savePose error: $e");
    }
  }

  void deletePose(String id) async {
    try {
      final url = Uri.parse("http://${_ip()}/robot_arm_panel/remove_pose.php?id=$id");
      final response = await http.get(url);
      print("deletePose response: ${response.statusCode} ${response.body}");
      fetchPoses();
    } catch (e) {
      print("deletePose error: $e");
    }
  }

  void loadPose(Map pose) {
    setState(() {
      motors[0] = double.tryParse(pose['motor1'].toString()) ?? 90;
      motors[1] = double.tryParse(pose['motor2'].toString()) ?? 90;
      motors[2] = double.tryParse(pose['motor3'].toString()) ?? 90;
      motors[3] = double.tryParse(pose['motor4'].toString()) ?? 90;
    });
  }

void runPose() async {
  try {
    final url = Uri.parse("http://${_ip()}/robot_arm_panel/run_pose.php");
    final response = await http.post(url, body: {
      "motor1": motors[0].toInt().toString(),
      "motor2": motors[1].toInt().toString(),
      "motor3": motors[2].toInt().toString(),
      "motor4": motors[3].toInt().toString(),
    });
    print("runPose response: ${response.statusCode} ${response.body}");
    if (response.statusCode == 200) {
      getRunPose();
    }
  } catch (e) {
    print("runPose error: $e");
  }
}

void getRunPose() async {
  try {
    final url = Uri.parse("http://${_ip()}/robot_arm_panel/get_run_pose.php");
    final response = await http.get(url);
    print("getRunPose response: ${response.statusCode} ${response.body}");
    if (response.statusCode == 200) {
      setState(() {
        _runPoseStatus = response.body; 
      });
    } else {
      setState(() {
        _runPoseStatus = "Error fetching run pose: ${response.statusCode}";
      });
    }
  } catch (e) {
    print("getRunPose error: $e");
    setState(() {
      _runPoseStatus = "Error: $e";
    });
  }
}

  void resetSliders() {
    setState(() {
      motors = [90, 90, 90, 90];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Robot Arm Control Panel')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            for (int i = 0; i < 4; i++) ...[
              Text("Motor ${i + 1}: ${motors[i].toInt()}"),
              Slider(
                min: 0,
                max: 180,
                value: motors[i],
                onChanged: (value) {
                  setState(() {
                    motors[i] = value;
                  });
                },
              ),
            ],
            SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                ElevatedButton(onPressed: resetSliders, child: Text("Reset")),
                ElevatedButton(onPressed: savePose, child: Text("Save Pose")),
                ElevatedButton(onPressed: runPose, child: Text("Run")),
              ],
            ),

            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8.0),
              child: Text(
                _runPoseStatus, 
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),

            SizedBox(height: 20),
            Text("Saved Poses", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),

            Expanded(
              child: ListView.builder(
                itemCount: poses.length,
                itemBuilder: (context, index) {
                  final pose = poses[index];
                  return ListTile(
                    title: Text(
                      "Pose ${index + 1}: ${pose['motor1']}, ${pose['motor2']}, ${pose['motor3']}, ${pose['motor4']}",
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: Icon(Icons.play_arrow, color: Colors.green),
                          onPressed: () => loadPose(pose),
                        ),
                        IconButton(
                          icon: Icon(Icons.delete, color: Colors.red),
                          onPressed: () => deletePose(pose['id'].toString()),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
