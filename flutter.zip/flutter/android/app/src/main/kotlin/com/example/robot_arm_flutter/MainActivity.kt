package com.example.robot_arm_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
